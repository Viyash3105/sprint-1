package com.tns.placementservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementserviceApplication.class, args);
	}

}
